// Let's Learn And Play — AI question maker (Vercel serverless function)
// Turns a lesson (text, PowerPoint/PDF text and slide pictures) into a
// 3-level differentiated quiz, or translates a quiz into Arabic.
// Only signed-in teachers (Google sign-in) can use it, so your API key
// can't be used by strangers.
//
// Environment variables (Vercel → Project → Settings → Environment Variables):
//   ANTHROPIC_API_KEY    your key from console.anthropic.com   (required)
//   FIREBASE_PROJECT_ID  your Firebase project id              (required)
//   ANTHROPIC_MODEL      optional, default "claude-sonnet-5-5"

import crypto from 'node:crypto';

export const config = { maxDuration: 60 };

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const TOPIC_IDS = ['math', 'science', 'english', 'geo', 'history', 'space', 'tech', 'digital', 'arabic', 'other'];

/* ---------- verify the Firebase sign-in token (no extra packages needed) ---------- */
const JWKS_URL = 'https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com';
let jwksCache = null, jwksAt = 0;
async function getKeys() {
  if (jwksCache && Date.now() - jwksAt < 3600e3) return jwksCache;
  const r = await fetch(JWKS_URL);
  if (!r.ok) throw new Error('could not load Google keys');
  jwksCache = (await r.json()).keys; jwksAt = Date.now();
  return jwksCache;
}
const b64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');
export async function verifyTeacher(token, projectId, keys) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) throw new Error('no token');
  const [h, p, sig] = parts;
  const header = JSON.parse(b64u(h).toString('utf8'));
  const payload = JSON.parse(b64u(p).toString('utf8'));
  if (header.alg !== 'RS256') throw new Error('bad alg');
  const key = (keys || await getKeys()).find(k => k.kid === header.kid);
  if (!key) throw new Error('unknown key');
  const ok = crypto.verify('RSA-SHA256', Buffer.from(h + '.' + p), crypto.createPublicKey({ key, format: 'jwk' }), b64u(sig));
  if (!ok) throw new Error('bad signature');
  const now = Math.floor(Date.now() / 1000);
  if (payload.aud !== projectId || payload.iss !== `https://securetoken.google.com/${projectId}`) throw new Error('wrong project');
  if (!payload.sub || payload.exp < now || payload.iat > now + 300) throw new Error('expired');
  if (!payload.firebase || payload.firebase.sign_in_provider !== 'google.com') throw new Error('teachers only');
  return payload;
}

/* ---------- prompts ---------- */
const LEVELS = {
  1: 'Level 1 "Warm-Up" (support): simple vocabulary, recall and recognition of key facts, short questions, very clear wrong options. Good for students who need extra support or are still learning the language.',
  2: 'Level 2 "Core" (on-level): understanding and applying the main ideas at the expected grade level.',
  3: 'Level 3 "Challenge" (stretch): analysis, inference, multi-step reasoning, cause and effect, comparing ideas, real-world transfer.'
};
function langLine(lang) {
  if (lang === 'ar') return 'LANGUAGE: Write the title and EVERY question, option and explanation in clear Modern Standard Arabic (العربية الفصحى) suited to the students\' grade. Keep numbers, formulas and code readable.';
  if (lang === 'en') return 'LANGUAGE: Write everything in English.';
  return 'LANGUAGE: Write in the same language as the lesson (if the lesson is in Arabic, use Modern Standard Arabic).';
}
const clip = (s, n) => String(s || '').slice(0, n);
export function lessonPrompt(b, level, n, imageCount) {
  const file = b.file && typeof b.file === 'object' ? b.file : null;
  const isPptx = file && file.kind === 'pptx';
  let material;
  if (file) {
    material = `LESSON MATERIAL: the teacher's ${isPptx ? 'PowerPoint presentation' : 'lesson file'} "${clip(file.name, 120)}" (${parseInt(file.pages) || '?'} ${isPptx ? 'slides' : 'pages'}).` +
      (isPptx ? ' Speaker notes, where present, show what the teacher explains out loud.' : '') +
      `\nText from the file:\n"""\n${clip(file.text, 40000) || '(no selectable text — use the attached pictures)'}\n"""\n` +
      (String(b.lesson || '').trim() ? `Teacher's extra notes:\n"""\n${clip(b.lesson, 8000)}\n"""\n` : '') +
      'First work out the lesson\'s main topic and key ideas, then base EVERY question on what the lesson actually teaches.';
  } else {
    material = `LESSON / TOPIC (from the teacher):\n"""\n${clip(b.lesson, 30000)}\n"""`;
  }
  const imgRule = imageCount
    ? `\n${imageCount} pictures from the lesson are attached, numbered 1 to ${imageCount} in order. Read them as part of the lesson. If a picture clearly helps a question (a diagram, map, photo or chart the question is about), set "image" to its number so students see it with the question; otherwise set "image" to 0.`
    : '\nSet "image" to 0 for every question.';
  return `You are an expert, fun teacher writing a multiple-choice quiz for a classroom game.

${material}

Students: ${clip(b.grade, 40) || 'school students'}.
${langLine(b.lang)}

Write exactly ${n} questions at this differentiation level (other levels are written separately — only write this one):
${LEVELS[level]}

Rules: 4 answer options, exactly ONE correct, plausible wrong options, options at most 12 words, questions at most 35 words, no "all/none of the above", friendly age-appropriate wording, no repeated questions. Give each question a one-sentence explanation of the right answer.
Make it fun: give each question "pic" — 1 to 3 emoji that illustrate it (for example "🌧️☁️" or "🦖").${imgRule}

Return ONLY JSON, no other text:
{"title":"short title for this game","topic":"one of: ${TOPIC_IDS.join(', ')}","questions":[{"q":"question","options":["A","B","C","D"],"answer":0,"explanation":"why","pic":"🌍","image":0}]}
"answer" is the 0-based index of the correct option.`;
}
export function translatePrompt(b) {
  const qs = (Array.isArray(b.questions) ? b.questions : []).slice(0, 80).map(q => ({ q: clip(q.q, 400), o: (Array.isArray(q.o) ? q.o : []).slice(0, 4).map(x => clip(x, 200)), ex: clip(q.ex, 400) }));
  return {
    count: qs.length,
    text: `Translate this classroom quiz into clear Modern Standard Arabic (العربية الفصحى) that school students can read easily. Keep the meaning and difficulty, keep numbers, formulas and code as they are, and keep every question's options in EXACTLY the same order. Also translate the title.
Title: ${JSON.stringify(clip(b.title, 200))}
Questions: ${JSON.stringify(qs)}
Return ONLY JSON: {"title":"...","questions":[{"q":"...","o":["...","...","...","..."],"ex":"..."}]} with the same number of questions (${qs.length}), in the same order.`
  };
}

/* ---------- Claude API ---------- */
export function parseJSON(t) {
  try { return JSON.parse(t); } catch (e) {}
  const m = t.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (m) { try { return JSON.parse(m[1]); } catch (e) {} }
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a >= 0 && b > a) return JSON.parse(t.slice(a, b + 1));
  throw new Error('the AI reply was not valid JSON');
}
async function ask(content, maxTokens) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, messages: [{ role: 'user', content }] })
  });
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error((j && j.error && j.error.message) || ('AI error ' + r.status));
  const text = (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
  return parseJSON(text);
}

/* ---------- handler ---------- */
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const projectId = process.env.FIREBASE_PROJECT_ID;
  if (!process.env.ANTHROPIC_API_KEY || !projectId) return res.status(500).json({ error: 'The server is missing ANTHROPIC_API_KEY or FIREBASE_PROJECT_ID (README step 6).' });
  try {
    await verifyTeacher((req.headers.authorization || '').replace(/^Bearer\s+/i, ''), projectId);
  } catch (e) {
    return res.status(401).json({ error: 'Please sign in with Google as a teacher first.' });
  }
  let b = req.body || {};
  if (typeof b === 'string') { try { b = JSON.parse(b); } catch (e) { b = {}; } }
  try {
    if (b.kind === 'translate') {
      const t = translatePrompt(b);
      if (!t.count) return res.status(400).json({ error: 'No questions to translate' });
      const out = await ask([{ type: 'text', text: t.text }], 12000);
      return res.status(200).json({ title: out.title || '', questions: Array.isArray(out.questions) ? out.questions : [] });
    }
    const hasLesson = String(b.lesson || '').trim().length >= 10 || (b.file && (b.file.text || (b.images || []).length));
    if (!hasLesson) return res.status(400).json({ error: 'Upload a lesson or type a topic first' });
    const n = Math.min(10, Math.max(1, parseInt(b.n) || 5));
    const images = (Array.isArray(b.images) ? b.images : []).filter(s => typeof s === 'string' && s.length < 2.5e6 && /^[A-Za-z0-9+/=]+$/.test(s)).slice(0, 10);
    const imgBlocks = images.map(data => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data } }));
    // the 3 levels are written at the same time, so the game is ready faster
    const results = await Promise.allSettled([1, 2, 3].map(l => ask([...imgBlocks, { type: 'text', text: lessonPrompt(b, l, n, images.length) }], 6000)));
    const questions = [];
    results.forEach((r, i) => { if (r.status === 'fulfilled') (r.value.questions || []).forEach(q => questions.push({ ...q, level: i + 1 })); });
    if (!questions.length) {
      const err = results.find(r => r.status === 'rejected');
      throw new Error(err ? err.reason.message : 'no questions came back');
    }
    const meta = [1, 0, 2].map(i => results[i]).find(r => r.status === 'fulfilled').value;
    return res.status(200).json({ title: meta.title || '', topic: TOPIC_IDS.includes(meta.topic) ? meta.topic : 'other', questions });
  } catch (e) {
    return res.status(502).json({ error: String((e && e.message) || e).slice(0, 300) });
  }
}
